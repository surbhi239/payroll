package com.payroll.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.LoginDetails;
import com.payroll.model.Skills;
import com.payroll.services.EmployeeService;
import com.payroll.services.LoginService;


@ComponentScan({"com.payroll"})
@SessionAttributes("loginDetails")
@Controller
public class TestController {

	public TestController() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/home")
	public String home(HttpServletRequest request){
		System.out.println("Home");
		
		System.out.println(request.getSession().getAttribute("loginDetails"));
		return "login";
		
	}
	
	
	

	@PostMapping("/LoginController")
	public ModelAndView login( LoginDetails loginDetails,LoginService loginService){
		
		System.out.println(loginDetails);
		System.out.println(loginService);
		
		String view="success";
		ModelAndView mav=null;
		
		try {
		boolean ch=	loginService.loginCheck(loginDetails);
		
		if(ch){
			 mav=new ModelAndView(view);
			
		}else{
			view="login";
			 mav=new ModelAndView(view);
			 mav.addObject("error", "username password is wrong");
		}
		
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			view="login";
			 mav=new ModelAndView(view);
			mav.addObject("error", e.getMessage());
			 e.printStackTrace();
		}
		
		return mav;
		
		
		
	}
	
	@GetMapping("/register")
	
	public String register(@ModelAttribute Employee employee){
		System.out.println(employee);
		return "registration";
	}
	
	@PostMapping("/reg")
	public String reg(EmployeeService service, Employee employee,Address address,Department department, String[] skills){
System.out.println(service);
		System.out.println(employee);
		System.out.println(address);
		System.out.println(department);
		System.out.println(skills);
		for (int i = 0; i < skills.length; i++) {
			System.out.println(skills[i]);
		}
		
		return "success";
		
		
		
	}
	
	
	

}
